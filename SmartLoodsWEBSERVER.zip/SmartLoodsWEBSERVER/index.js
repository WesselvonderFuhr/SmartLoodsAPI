//imports
const SerialPort = require('serialport');
const FormData = require('form-data');
const XMLHttpRequest = require('XMLHttpRequest').XMLHttpRequest;

var port = "COM3";
var sp = new SerialPort(port, {
  baudRate: 9600,
});

sp.on('open', onPortOpen);
sp.on('data', onData);
sp.on('close', onClose);
sp.on('error', onError);

function onPortOpen(){
    console.log("port is open");
}

function onData(d)
{
    console.log("new data" + d);
    post(d);
}

function onClose(){
    console.log("port is closed");
}
function onError(){
    console.log("something went wrong");
}




function post(value){
  //prepare data
  let data = {    
    "name" : "NumberOfPeople",
    "value" : value
  };
  var formBody = [];
  for (var property in data) {
    var encodedKey = encodeURIComponent(property);
    var encodedValue = encodeURIComponent(data[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");

  var xhr = new XMLHttpRequest();
  xhr.open("POST", "https://smartloods.herokuapp.com/sensors", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.send(formBody);
}

